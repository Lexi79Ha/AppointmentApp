﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Reflection.Emit;
using System.Windows.Forms;

namespace C969_A_Harris
{
    public partial class ModifyAppointmentForm : Form
    {
        private SelectedAppointment selectedAppointment;
        private BindingList<Customer> customerList = new BindingList<Customer>();
        private BindingList<Appointment> appointments = new BindingList<Appointment>();
        private Customer selectedCustomer;
        private Database database;
        private readonly string connectionString = Configuration.ConnectionString;
        private User loggedInUser;

        public ModifyAppointmentForm(User loggedInUser, SelectedAppointment appointment)
        {
            InitializeComponent();
            this.loggedInUser = loggedInUser;
            this.selectedAppointment = appointment;  
            database = new Database(loggedInUser);

            SetupDataGridView();
            PopulateAppointmentDetails();
            PopulateTimeSlots();
            LoadAllAppointments();
        }


        private void PopulateTimeSlots()
        {
            TimeSpan interval = TimeSpan.FromMinutes(15);
            TimeSpan startTime = new TimeSpan(9, 0, 0); 
            TimeSpan endTime = new TimeSpan(17, 0, 0); 

            comboBoxStartTime.Items.Clear();
            comboBoxEndTime.Items.Clear();

            for (TimeSpan time = startTime; time <= endTime; time += interval)
            {
                DateTime timeAsDateTime = DateTime.Today.Add(time);
                string timeString = timeAsDateTime.ToString("hh:mm tt");

                comboBoxStartTime.Items.Add(timeString);
                comboBoxEndTime.Items.Add(timeString);
            }

            if (comboBoxStartTime.Items.Count > 0)
                comboBoxStartTime.SelectedIndex = 0;
            if (comboBoxEndTime.Items.Count > 0)
                comboBoxEndTime.SelectedIndex = 0;
        }

        private void PopulateAppointmentDetails()
        {
            if (selectedAppointment != null)
            {
                if (customerList != null)
                {
                    selectedCustomer = customerList.FirstOrDefault(c => c.CustomerId == selectedAppointment.CustomerId);
                    if (selectedCustomer != null)
                    {
                        if (dataGridView2 != null)
                        {
                            foreach (DataGridViewRow row in dataGridView2.Rows)
                            {
                                if (row.DataBoundItem is Customer customer && customer.CustomerId == selectedCustomer.CustomerId)
                                {
                                    row.Selected = true;
                                    break;
                                }
                            }
                        }
                    }
                }

                descriptiontxt.Text = selectedAppointment.Description;
                type.Text = selectedAppointment.Type;
                dateTimePicker.Value = selectedAppointment.Start;
                comboBoxStartTime.SelectedItem = selectedAppointment.Start.ToString("hh:mm tt");
                comboBoxEndTime.SelectedItem = selectedAppointment.End.ToString("hh:mm tt");
            }
        }


        private void SetupDataGridView()
        {
            dataGridView2.AutoGenerateColumns = false;
            dataGridView2.MultiSelect = false;

            dataGridView2.Columns.Clear();
            dataGridView2.Columns.Add("appointmentId", "Appointment ID");
            dataGridView2.Columns["appointmentId"].Visible = false;
            dataGridView2.Columns.Add("CustomerName", "Customer Name");
            dataGridView2.Columns.Add("Type", "Type");
            dataGridView2.Columns.Add("Description", "Description");
            dataGridView2.Columns.Add("Location", "Location");
            dataGridView2.Columns.Add("Start", "Start");
            dataGridView2.Columns.Add("End", "End");
        }

        private void LoadAllAppointments()
        {
            List<SelectedAppointment> appointments = GetAllAppointments();
            if (appointments == null)
            {
                MessageBox.Show("Failed to retrieve appointments.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            dataGridView2.Rows.Clear();
            foreach (var appointment in appointments)
            {
                if (appointment == null)
                {
                    MessageBox.Show("Encountered null appointment.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    continue;
                }

                Console.WriteLine($"Adding row - CustomerName: {appointment.CustomerName}, Start: {appointment.Start}, End: {appointment.End}");

                dataGridView2.Rows.Add(
                    appointment.AppointmentId,
                    appointment.CustomerName,
                    appointment.Type,
                    appointment.Description,
                    appointment.Location,
                    appointment.Start.ToString("M/d/yyyy h:mm:ss tt"),
                    appointment.End.ToString("M/d/yyyy h:mm:ss tt")
                );
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView2.Rows[e.RowIndex];

                string appointmentId = selectedRow.Cells["appointmentId"].Value?.ToString();
                string customerName = selectedRow.Cells["CustomerName"].Value?.ToString();
                string location = selectedRow.Cells["Location"].Value?.ToString();
                string type = selectedRow.Cells["Type"].Value?.ToString();
                string description = selectedRow.Cells["Description"].Value?.ToString();
                string startValue = selectedRow.Cells["Start"].Value?.ToString();
                string endValue = selectedRow.Cells["End"].Value?.ToString();

                DateTime start, end;
                string format = "M/d/yyyy h:mm:ss tt";

                TimeZoneInfo easternTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                TimeZoneInfo localTimeZone = TimeZoneInfo.Local;

                if (DateTime.TryParseExact(startValue, format, null, System.Globalization.DateTimeStyles.None, out start) &&
                    DateTime.TryParseExact(endValue, format, null, System.Globalization.DateTimeStyles.None, out end))
                {
                   
                    DateTime startUtc = TimeZoneInfo.ConvertTimeToUtc(start, easternTimeZone);
                    DateTime endUtc = TimeZoneInfo.ConvertTimeToUtc(end, easternTimeZone);

                   
                    DateTime startLocal = TimeZoneInfo.ConvertTimeFromUtc(startUtc, localTimeZone);
                    DateTime endLocal = TimeZoneInfo.ConvertTimeFromUtc(endUtc, localTimeZone);

                   
                    this.name.Text = customerName;
                    this.location.Text = location;
                    this.description.Text = description;
                    this.type.Text = type;
                    dateTimePicker1.Value = startLocal.Date;
                    this.appointmentid.Text = appointmentId;

                   
                    string startTimeString = startLocal.ToString("hh:mm tt");
                    string endTimeString = endLocal.ToString("hh:mm tt");

                    comboBoxStartTime.SelectedItem = startTimeString;
                    comboBoxEndTime.SelectedItem = endTimeString;
                }
                else
                {
                    MessageBox.Show($"Invalid date/time format in the selected row. Start: {startValue}, End: {endValue}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                selectedCustomer = customerList.FirstOrDefault(c => c.Name == customerName);
            }
        }

        private List<SelectedAppointment> GetAllAppointments()
        {
            List<SelectedAppointment> appointments = new List<SelectedAppointment>();

            string query = @"
        SELECT a.appointmentId, a.type, a.description, a.location, a.start, a.end, c.customerName, a.customerId
        FROM appointment a 
        JOIN customer c ON a.customerId = c.customerId";

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    MySqlCommand command = new MySqlCommand(query, connection);
                    MySqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        SelectedAppointment selectedAppointment = new SelectedAppointment(
                            reader.GetInt32("appointmentId"),
                            reader["customerName"].ToString(),
                            reader["type"].ToString(),
                            reader["description"].ToString(),
                            Convert.ToDateTime(reader["start"]),
                            Convert.ToDateTime(reader["end"]),
                            reader["location"].ToString(),
                            reader.GetInt32("customerId")
                        );
                        appointments.Add(selectedAppointment);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error retrieving appointments: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return appointments;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string location = this.location.Text.Trim();
            string description = this.description.Text.Trim();
            string type = this.type.Text.Trim();
            string userName = loggedInUser.UserName.Trim();

            if (!int.TryParse(this.appointmentid.Text.Trim(), out int appointmentId))
            {
                MessageBox.Show("Invalid appointment ID. Please enter a valid number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DateTime startTime = DateTime.ParseExact(comboBoxStartTime.SelectedItem.ToString(), "hh:mm tt", null);
            DateTime endTime = DateTime.ParseExact(comboBoxEndTime.SelectedItem.ToString(), "hh:mm tt", null);

            DateTime appointmentStartTime = dateTimePicker1.Value.Date + startTime.TimeOfDay;
            DateTime appointmentEndTime = dateTimePicker1.Value.Date + endTime.TimeOfDay;

            TimeZoneInfo estZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
            DateTime estStartTime = TimeZoneInfo.ConvertTime(appointmentStartTime, estZone);
            DateTime estEndTime = TimeZoneInfo.ConvertTime(appointmentEndTime, estZone);

            if (estStartTime >= estEndTime)
            {
                MessageBox.Show("End time must be after the start time.", "Invalid Time", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsOverlapping(estStartTime, estEndTime, appointmentId))
            {
                MessageBox.Show("The selected time overlaps with an existing appointment.", "Overlapping Appointment", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    MySqlTransaction transaction = connection.BeginTransaction();

                    try
                    {
                        string updateAppointmentQuery = @"
                UPDATE appointment
                SET location = @location, 
                    description = @description, 
                    type = @type, 
                    start = @start, 
                    end = @end, 
                    lastUpdate = @lastUpdate, 
                    lastUpdateBy = @lastUpdateBy
                WHERE appointmentId = @appointmentId";

                        using (MySqlCommand updateAppointmentCmd = new MySqlCommand(updateAppointmentQuery, connection))
                        {
                            updateAppointmentCmd.Parameters.AddWithValue("@location", location);
                            updateAppointmentCmd.Parameters.AddWithValue("@description", description);
                            updateAppointmentCmd.Parameters.AddWithValue("@type", type);
                            updateAppointmentCmd.Parameters.AddWithValue("@start", estStartTime);
                            updateAppointmentCmd.Parameters.AddWithValue("@end", estEndTime);
                            updateAppointmentCmd.Parameters.AddWithValue("@lastUpdate", DateTime.UtcNow);
                            updateAppointmentCmd.Parameters.AddWithValue("@lastUpdateBy", userName);
                            updateAppointmentCmd.Parameters.AddWithValue("@appointmentId", appointmentId);

                            int rowsAffected = updateAppointmentCmd.ExecuteNonQuery();
                            Console.WriteLine($"Rows affected: {rowsAffected}");

                            if (rowsAffected == 0)
                            {
                                MessageBox.Show("No appointment was updated. Please check the Appointment ID and ensure it exists.", "Update Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                            else
                            {
                                transaction.Commit();
                                MessageBox.Show("Appointment successfully updated.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                this.Close();

                                AppointmentCalendarForm appointmentCalendarForm = new AppointmentCalendarForm(loggedInUser, null);
                                appointmentCalendarForm.Show();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show($"An error occurred while updating the appointment: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        Console.WriteLine($"Update exception: {ex.Message}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database connection failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Console.WriteLine($"Connection exception: {ex.Message}");
            }
        }



        private bool IsOverlapping(DateTime start, DateTime end, int appointmentId)
        {
            bool isOverlapping = false;

            string query = @"
                SELECT COUNT(*) 
                FROM appointment 
                WHERE (@Start < end) AND (@End > start)
                AND appointmentId <> @AppointmentId";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@Start", start);
                command.Parameters.AddWithValue("@End", end);
                command.Parameters.AddWithValue("@AppointmentId", appointmentId);

                int overlappingCount = Convert.ToInt32(command.ExecuteScalar());
                isOverlapping = overlappingCount > 0;
            }

            return isOverlapping;
        }

        

        private void button5_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(this.appointmentid.Text.Trim(), out int appointmentId))
            {
                MessageBox.Show("Invalid appointment ID. Please enter a valid number.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this appointment?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    using (MySqlConnection connection = new MySqlConnection(connectionString))
                    {
                        connection.Open();
                        MySqlTransaction transaction = connection.BeginTransaction();

                        try
                        {
                            string deleteAppointmentQuery = @"
                    DELETE FROM appointment
                    WHERE appointmentId = @appointmentId";

                            using (MySqlCommand deleteAppointmentCmd = new MySqlCommand(deleteAppointmentQuery, connection))
                            {
                                deleteAppointmentCmd.Parameters.AddWithValue("@appointmentId", appointmentId);

                                int rowsAffected = deleteAppointmentCmd.ExecuteNonQuery();
                                Console.WriteLine($"Rows affected: {rowsAffected}");

                                if (rowsAffected == 0)
                                {
                                    MessageBox.Show("No appointment was deleted. Please check the Appointment ID and ensure it exists.", "Delete Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                                else
                                {
                                    transaction.Commit();
                                    MessageBox.Show("Appointment successfully deleted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                    LoadAllAppointments(); 
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show($"An error occurred while deleting the appointment: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            Console.WriteLine($"Delete exception: {ex.Message}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Database connection failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Console.WriteLine($"Connection exception: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Deletion canceled.", "Canceled", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        private void button4_Click(object sender, EventArgs e)
   
        {
            string searchTerm = textBox6.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(searchTerm))
            {
                MessageBox.Show("Please enter a search term.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool found = false; // To track if we found any matching row

            dataGridView2.ClearSelection();

            foreach (DataGridViewRow row in dataGridView2.Rows)
            {
                if (row.IsNewRow) continue;

                string name = row.Cells["CustomerName"].Value.ToString().ToLower();

                if (name.Contains(searchTerm))
                {
                   
                    row.Selected = true;
                    found = true;
                }
            }

            if (!found)
            {
                MessageBox.Show("No matching customers found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

    }
}
