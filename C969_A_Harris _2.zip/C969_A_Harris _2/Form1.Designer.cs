﻿using System.Drawing;

namespace C969_A_Harris
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.loginlabel = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtUserpassword = new System.Windows.Forms.TextBox();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.labelusername = new System.Windows.Forms.Label();
            this.labelpassword = new System.Windows.Forms.Label();
            this.labeltimezone = new System.Windows.Forms.Label();
            this.region1 = new System.Windows.Forms.Label();
            this.languagetxt = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // loginlabel
            // 
            this.loginlabel.AutoSize = true;
            this.loginlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginlabel.Location = new System.Drawing.Point(228, 22);
            this.loginlabel.Name = "loginlabel";
            this.loginlabel.Size = new System.Drawing.Size(62, 24);
            this.loginlabel.TabIndex = 0;
            this.loginlabel.Text = "Login";
            this.loginlabel.Click += new System.EventHandler(this.loginlabel_Click);
            // 
            // txtUsername
            // 
            this.txtUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtUsername.Location = new System.Drawing.Point(215, 75);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(176, 26);
            this.txtUsername.TabIndex = 1;
            this.txtUsername.TextChanged += new System.EventHandler(this.txtUsername_TextChanged);
            // 
            // txtUserpassword
            // 
            this.txtUserpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtUserpassword.Location = new System.Drawing.Point(215, 112);
            this.txtUserpassword.Name = "txtUserpassword";
            this.txtUserpassword.Size = new System.Drawing.Size(176, 26);
            this.txtUserpassword.TabIndex = 2;
            // 
            // btnEnter
            // 
            this.btnEnter.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btnEnter.Location = new System.Drawing.Point(215, 199);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 27);
            this.btnEnter.TabIndex = 3;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = false;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.btnExit.Location = new System.Drawing.Point(316, 199);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 27);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // labelusername
            // 
            this.labelusername.AutoSize = true;
            this.labelusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.labelusername.Location = new System.Drawing.Point(54, 75);
            this.labelusername.Name = "labelusername";
            this.labelusername.Size = new System.Drawing.Size(77, 18);
            this.labelusername.TabIndex = 5;
            this.labelusername.Text = "Username";
            // 
            // labelpassword
            // 
            this.labelpassword.AutoSize = true;
            this.labelpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.labelpassword.Location = new System.Drawing.Point(54, 120);
            this.labelpassword.Name = "labelpassword";
            this.labelpassword.Size = new System.Drawing.Size(75, 18);
            this.labelpassword.TabIndex = 6;
            this.labelpassword.Text = "Password";
            // 
            // labeltimezone
            // 
            this.labeltimezone.AutoSize = true;
            this.labeltimezone.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.labeltimezone.Location = new System.Drawing.Point(54, 153);
            this.labeltimezone.Name = "labeltimezone";
            this.labeltimezone.Size = new System.Drawing.Size(79, 18);
            this.labeltimezone.TabIndex = 7;
            this.labeltimezone.Text = "Time Zone";
            // 
            // region1
            // 
            this.region1.AutoSize = true;
            this.region1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.region1.Location = new System.Drawing.Point(212, 162);
            this.region1.Name = "region1";
            this.region1.Size = new System.Drawing.Size(61, 18);
            this.region1.TabIndex = 8;
            this.region1.Text = "Pending";
            // 
            // languagetxt
            // 
            this.languagetxt.AutoSize = true;
            this.languagetxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F);
            this.languagetxt.Location = new System.Drawing.Point(8, 5);
            this.languagetxt.Name = "languagetxt";
            this.languagetxt.Size = new System.Drawing.Size(0, 18);
            this.languagetxt.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(525, 328);
            this.Controls.Add(this.languagetxt);
            this.Controls.Add(this.region1);
            this.Controls.Add(this.labeltimezone);
            this.Controls.Add(this.labelpassword);
            this.Controls.Add(this.labelusername);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.txtUserpassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.loginlabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label loginlabel;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtUserpassword;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label labelusername;
        private System.Windows.Forms.Label labelpassword;
        private System.Windows.Forms.Label labeltimezone;
        private System.Windows.Forms.Label region1;
        private System.Windows.Forms.Label languagetxt;
    }
}

