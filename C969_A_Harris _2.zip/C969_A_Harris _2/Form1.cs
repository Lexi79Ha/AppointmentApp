﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace C969_A_Harris
{
    public partial class Form1 : Form
    {
        private Database database;
        private Appointment selectedAppointment;
        public User loggedInUser;
        private readonly LoginHistoryService loginHistoryService;
        private readonly string filePath;
        

        public Form1(User loggedInUser, Appointment appointment)
        {
            InitializeComponent();

            string username = txtUsername.Text;
            string password = txtUserpassword.Text;
            this.selectedAppointment = appointment;
            this.loggedInUser = loggedInUser;
            this.filePath = "Login_History.txt"; 

            loginHistoryService = new LoginHistoryService();

            database = new Database(loggedInUser);

            LoadLanguageSettings();
        }

        private void LoadLanguageSettings()
        {
            string culture = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
            if (culture == "es") // Spanish
            {
                changeLoginToSpanish();
                ShowUserRegion1();
            }
            else
            {
                ShowUserRegion1();
            }

            ApplyResourcesRecursively(this);
        }

        private void changeLoginToSpanish()
        {
            loginlabel.Text = "Pantalla de inicio de sesión";
            labelusername.Text = "Nombre de usuario";
            labelpassword.Text = "Contraseña";
            btnExit.Text = "Salir";
            btnEnter.Text = "Entrar";
        }

        private void ApplyResourcesRecursively(Control control)
        {
            ComponentResourceManager resources = new ComponentResourceManager(this.GetType());
            resources.ApplyResources(control, "$this", Thread.CurrentThread.CurrentUICulture);
            foreach (Control childControl in control.Controls)
            {
                ApplyResourcesRecursively(childControl);
            }
        }

        public void RecordLoginHistory(User user)
        {
            
            Console.WriteLine($"Recording login for: {user.UserName}");

            string logEntry = $"{DateTime.Now}: User '{user.UserName}' logged in.";

            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                writer.WriteLine(logEntry);
            }
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtUserpassword.Text;

        
            string culture = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;

            string successMessage = culture == "es" ? "¡Inicio de sesión exitoso!" : "Login successful!";
            string errorMessage = culture == "es" ? "Nombre de usuario o contraseña inválidos." : "Invalid username or password.";
            string errorTitle = culture == "es" ? "Error" : "Error";
            string successTitle = culture == "es" ? "Éxito" : "Success";
           



            try
            {
                List<User> userList = database.GetAllUsers();
                bool isValidUser = userList.Any(user => user.UserName == username && user.Password == password);

                if (isValidUser)
                {
                    loggedInUser = new User(1, username, password, 1, DateTime.Now, "system", DateTime.Now, "system");
                    MessageBox.Show(successMessage, successTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);

                    AppointmentCalendarForm appointmentCalendarForm = new AppointmentCalendarForm(loggedInUser, selectedAppointment);
                    appointmentCalendarForm.Show();

                    loginHistoryService.RecordLoginHistory(loggedInUser);

                    this.Hide();
                }
                else
                {
                    MessageBox.Show(errorMessage, errorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{(culture == "es" ? "Error:" : "Error:")} {ex.Message}", errorTitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ShowUserRegion1()
        {
            try
            {
                region1.Text = "Test: Region Display";
                region1.Refresh();

                CultureInfo cultureInfo = CultureInfo.CurrentCulture;
                RegionInfo regionInfo = new RegionInfo(cultureInfo.Name);
                region1.Text = $"Region: {regionInfo.DisplayName}";
                region1.Refresh();

                TimeZoneInfo localTimeZone = TimeZoneInfo.Local;
                string timeZoneDisplayName = localTimeZone.DisplayName;

                region1.Text = $"{timeZoneDisplayName}";
                region1.Refresh();
            }
            catch (Exception ex)
            {
                region1.Text = $"Error: {ex.Message}";
                region1.Refresh();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void loginlabel_Click(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}