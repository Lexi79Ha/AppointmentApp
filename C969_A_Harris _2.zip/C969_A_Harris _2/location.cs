﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C969_A_Harris
{
    public class UserLocationHelper
    {
        public static string GetUserAppDataPath()
        {
            return Application.LocalUserAppDataPath;
        }
    }
}