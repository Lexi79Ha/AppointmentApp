﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C969_A_Harris
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            User loggedInUser = new User(1, "username", "password", 1, DateTime.Now, "system", DateTime.Now, "system");
            Appointment selectedAppointment = null; 

            Application.Run(new Form1(loggedInUser, selectedAppointment));
        }
    }
}