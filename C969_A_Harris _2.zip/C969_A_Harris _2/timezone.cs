﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C969_A_Harris
{
    public static class TimeZone
    {
       
        public static string GetUserTimeZoneId()
        {
            return TimeZoneInfo.Local.Id;
        }

        public static string GetUserTimeZoneDisplayName()
        {
            return TimeZoneInfo.Local.DisplayName;
        }
    }
}