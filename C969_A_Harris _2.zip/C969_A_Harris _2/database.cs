﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Windows.Forms;

namespace C969_A_Harris
{
    public class Database
    {
        private readonly string connectionString = ConfigurationManager.ConnectionStrings["MySqlConnectionString"].ConnectionString;
   


        private User LoggedInUser;  
        public Database(User loggedInUser)
        {
            LoggedInUser = loggedInUser;
        }

        public List<User> GetAllUsers()
        {
            List<User> userList = new List<User>();

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT * FROM user";
                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataReader dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    int userID = Convert.ToInt32(dataReader["userID"]); 
                    string userName = dataReader["userName"].ToString(); 
                    string password = dataReader["password"].ToString(); 
                    int active = Convert.ToInt32(dataReader["active"]); 
                    DateTime createDate = Convert.ToDateTime(dataReader["createDate"]).ToLocalTime(); 
                    string createdBy = dataReader["createdBy"].ToString(); 
                    DateTime lastUpdate = Convert.ToDateTime(dataReader["lastUpdate"]).ToLocalTime(); 
                    string lastUpdateBy = dataReader["lastUpdateBy"].ToString(); 

                    User newUser = new User(userID, userName, password, active, createDate, createdBy, lastUpdate, lastUpdateBy);
                    userList.Add(newUser);
                }

                connection.Close();
            }

            return userList;
        }

        public List<Customer> GetAllCustomers()
        {
            List<Customer> customerList = new List<Customer>();

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = @"
            SELECT c.customerId, c.customerName, a.address, a.phone, ci.city, co.country, a.postalCode, a.addressId, ci.cityId, co.countryId
            FROM customer c 
            JOIN address a ON c.addressId = a.addressId
            JOIN city ci ON a.cityId = ci.cityId
            JOIN country co ON ci.countryId = co.countryId
        ";

                MySqlCommand command = new MySqlCommand(query, connection);
                MySqlDataReader dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    int customerId = Convert.ToInt32(dataReader["customerId"]);
                    string name = dataReader["customerName"].ToString();
                    string address = dataReader["address"].ToString();
                    string phoneNumber = dataReader["phone"].ToString();
                    string city = dataReader["city"].ToString();
                    string country = dataReader["country"].ToString();
                    string zipCode = dataReader["postalCode"].ToString();
                    int addressId = Convert.ToInt32(dataReader["addressId"]);
                    int cityId = Convert.ToInt32(dataReader["cityId"]);
                    int countryId = Convert.ToInt32(dataReader["countryId"]);

                    Customer customer = new Customer(customerId, name, address, phoneNumber, city, country, zipCode, addressId, cityId, countryId);
                    customerList.Add(customer);
                }

                connection.Close();
            }

            return customerList;
        }
    }
}