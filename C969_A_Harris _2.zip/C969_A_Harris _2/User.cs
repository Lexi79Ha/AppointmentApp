﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C969_A_Harris
{
    public class User
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public int UserLevel { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime LastUpdated { get; set; }
        public string LastUpdatedBy { get; set; }


        public User(int userId, string userName, string password, int userLevel, DateTime createdDate, string createdBy, DateTime lastUpdated, string lastUpdatedBy)
        {
            UserId = userId;
            UserName = userName;
            Password = password;
            UserLevel = userLevel;
            CreatedDate = createdDate;
            CreatedBy = createdBy;
            LastUpdated = lastUpdated;
            LastUpdatedBy = lastUpdatedBy;
        }
    }
}
