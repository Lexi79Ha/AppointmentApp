﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using MySql.Data.MySqlClient;



namespace C969_A_Harris
{
    public class SelectedAppointment
    {
        public int AppointmentId { get; set; }
        public string CustomerName { get; set; }
        public string Type { get; set; }
        public string Description { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public string Location { get; set; }

        public int CustomerId { get; set; }


        public SelectedAppointment(int appointmentId, string customerName, string type, string description, DateTime start, DateTime end, string location, int customerId)
        {
            AppointmentId = appointmentId;
            CustomerName = customerName;
            Type = type;
            Description = description;
            Start = start;
            End = end;
            Location = location;
            CustomerId = customerId;
        }
    }
}
