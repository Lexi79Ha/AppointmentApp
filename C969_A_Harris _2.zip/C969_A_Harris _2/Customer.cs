﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C969_A_Harris
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public string ZipCode { get; set; }
        public string createdBy { get; set; }
        public int AddressId { get; set; } 
        
        public int CityId { get; set; }

        public int CountryId { get; set; }
        
        
        

    public Customer(int customerId, string name, string address, string phoneNumber, string city, string country, string zipCode, int addressId, int cityId, int countryId)
        {
            CustomerId = customerId;
            Name = name;
            Address = address;
            PhoneNumber = phoneNumber;
            City = city;
            Country = country;
            ZipCode = zipCode;
            AddressId = addressId;
            CityId = cityId;
            CountryId = countryId;
         
        }


        public bool Validate(out string errorMessage)
        {
            errorMessage = string.Empty;
            return true;
        }
    }
}