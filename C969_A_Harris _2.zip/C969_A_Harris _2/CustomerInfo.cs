﻿using MySql.Data.MySqlClient;
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace C969_A_Harris
{
    public partial class CustomerForm : Form
    {
        private BindingList<Customer> customerList = new BindingList<Customer>();
        private Customer selectedCustomer;
        private Database database;
        private readonly string connectionString = Configuration.ConnectionString;
        private User loggedInUser;

        public CustomerForm(User loggedInUser)
        {
            InitializeComponent();
            this.loggedInUser = loggedInUser;
           
            database = new Database(loggedInUser);
            SetupDataGridView();
            LoadCustomers();
            

            dataGridViewCustomerInfo.CellClick += dataGridViewCustomerInfo_CellClick;
        }

        private void SetupDataGridView()
        {
           
            dataGridViewCustomerInfo.AutoGenerateColumns = false;
            dataGridViewCustomerInfo.ColumnHeadersDefaultCellStyle.SelectionBackColor = dataGridViewCustomerInfo.ColumnHeadersDefaultCellStyle.BackColor;
            dataGridViewCustomerInfo.MultiSelect = false;

           
            dataGridViewCustomerInfo.Columns.Clear();

            dataGridViewCustomerInfo.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "customerId",
                HeaderText = "Customer ID",

                DataPropertyName = "CustomerId",
                Visible = false
            });

            dataGridViewCustomerInfo.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "addressId",
                HeaderText = "Address Id",

                DataPropertyName = "addressId",
                Visible = false
            });

            dataGridViewCustomerInfo.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "cityId",
                HeaderText = "City Id",

                DataPropertyName = "cityId",
                Visible = false
            });

            dataGridViewCustomerInfo.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "countryId",
                HeaderText = "Country Id",

                DataPropertyName = "countryId",
                Visible = false
            });



            dataGridViewCustomerInfo.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Name",
                HeaderText = "Name",
                DataPropertyName = "Name"
            });

            dataGridViewCustomerInfo.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Address",
                HeaderText = "Address",
                DataPropertyName = "Address"
            });

            dataGridViewCustomerInfo.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "PhoneNumber",
                HeaderText = "Phone Number",
                DataPropertyName = "PhoneNumber"
            });

            dataGridViewCustomerInfo.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "City",
                HeaderText = "City",
                DataPropertyName = "City"
            });

            dataGridViewCustomerInfo.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Country",
                HeaderText = "Country",
                DataPropertyName = "Country"
            });

            dataGridViewCustomerInfo.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ZipCode",
                HeaderText = "Zip Code",
                DataPropertyName = "ZipCode"
            });
        }

        private void LoadCustomers()
        {
            var customers = database.GetAllCustomers();
            foreach (var customer in customers)
            {
                Console.WriteLine($"Customer ID: {customer.CustomerId}"); 
            }
            customerList = new BindingList<Customer>(customers);
            dataGridViewCustomerInfo.DataSource = customerList;
        }



        private void dataGridViewCustomerInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedCustomer = (Customer)dataGridViewCustomerInfo.Rows[e.RowIndex].DataBoundItem;

                txtCustomerName.Text = selectedCustomer.Name;
                txtCustomerAddress.Text = selectedCustomer.Address;
                txtCustomerPhoneNumber.Text = selectedCustomer.PhoneNumber;
                txtCustomerCity.Text = selectedCustomer.City;
                txtCustomerCountry.Text = selectedCustomer.Country;
                txtCustomerZip.Text = selectedCustomer.ZipCode;
            }
        }

        private void ClearForm()
        {
            txtCustomerName.Clear();
            txtCustomerAddress.Clear();
            txtCustomerPhoneNumber.Clear();
            txtCustomerCity.Clear();
            txtCustomerCountry.Clear();
            txtCustomerZip.Clear();
            selectedCustomer = null;
        }

        private void btnCustomerModify_Click(object sender, EventArgs e)
        {
            if (selectedCustomer == null)
            {
                MessageBox.Show("No customer selected for modification.");
                return;
            }

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                string query = @"
            UPDATE customer
            JOIN address ON customer.addressId = address.addressId
            JOIN city ON address.cityId = city.cityId
            JOIN country ON city.countryId = country.countryId
            SET
                customer.customerName = @CustomerName,
                address.address = @Address,
                address.phone = @Phone,
                city.city = @City,
                country.country = @Country,
                address.postalCode = @PostalCode
            WHERE customer.customerId = @CustomerId;
        ";

                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@CustomerName", txtCustomerName.Text);
                    command.Parameters.AddWithValue("@Address", txtCustomerAddress.Text);
                    command.Parameters.AddWithValue("@Phone", txtCustomerPhoneNumber.Text);
                    command.Parameters.AddWithValue("@City", txtCustomerCity.Text);
                    command.Parameters.AddWithValue("@Country", txtCustomerCountry.Text);
                    command.Parameters.AddWithValue("@PostalCode", txtCustomerZip.Text);
                    command.Parameters.AddWithValue("@CustomerId", selectedCustomer.CustomerId);

                    // Execute the update command
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        MessageBox.Show("No rows were updated. Check if the CustomerId is correct.");
                    }
                    else
                    {
                        MessageBox.Show("Customer information updated successfully.");
                        LoadCustomers(); // Reload the customer list
                    }
                }

                connection.Close();
            }
        }




        private void btnCustomerDelete_Click(object sender, EventArgs e)
        {
            if (selectedCustomer == null)
            {
                MessageBox.Show("No customer selected for deletion.", "Selection Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

         
            var confirmResult = MessageBox.Show("Are you sure you want to delete this customer? This will also remove related appointments.", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (confirmResult == DialogResult.Yes)
            {
                try
                {
                    using (MySqlConnection connection = new MySqlConnection(connectionString))
                    {
                        connection.Open();

                      
                        string checkCustomerQuery = "SELECT COUNT(*) FROM customer WHERE customerId = @customerId";
                        MySqlCommand checkCustomerCmd = new MySqlCommand(checkCustomerQuery, connection);
                        checkCustomerCmd.Parameters.AddWithValue("@customerId", selectedCustomer.CustomerId);

                        int count = Convert.ToInt32(checkCustomerCmd.ExecuteScalar());
                        if (count == 0)
                        {
                            MessageBox.Show("Customer does not exist. Cannot delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                       
                        string deleteAppointmentsQuery = "DELETE FROM appointment WHERE customerId = @customerId";
                        MySqlCommand deleteAppointmentsCmd = new MySqlCommand(deleteAppointmentsQuery, connection);
                        deleteAppointmentsCmd.Parameters.AddWithValue("@customerId", selectedCustomer.CustomerId);
                        deleteAppointmentsCmd.ExecuteNonQuery();

               
                        string checkAddressIdQuery = "SELECT COUNT(*) FROM customer WHERE addressId = @addressId";
                        MySqlCommand checkAddressIdCmd = new MySqlCommand(checkAddressIdQuery, connection);
                        checkAddressIdCmd.Parameters.AddWithValue("@addressId", selectedCustomer.AddressId);

                        int addressCount = Convert.ToInt32(checkAddressIdCmd.ExecuteScalar());

                       
                        if (addressCount == 0)
                        {
                            string deleteAddressQuery = "DELETE FROM address WHERE addressId = @addressId";
                            MySqlCommand deleteAddressCmd = new MySqlCommand(deleteAddressQuery, connection);
                            deleteAddressCmd.Parameters.AddWithValue("@addressId", selectedCustomer.AddressId);
                            deleteAddressCmd.ExecuteNonQuery();
                        }

                      
                        string deleteCustomerQuery = "DELETE FROM customer WHERE customerId = @customerId";
                        MySqlCommand deleteCustomerCmd = new MySqlCommand(deleteCustomerQuery, connection);
                        deleteCustomerCmd.Parameters.AddWithValue("@customerId", selectedCustomer.CustomerId);

                        int rowsAffected = deleteCustomerCmd.ExecuteNonQuery();
                        if (rowsAffected == 0)
                        {
                            MessageBox.Show("Deletion failed. No rows affected.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            MessageBox.Show("Customer deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearForm();
                            LoadCustomers();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        

  


        private void txtCustomerPhoneNumber_TextChanged(object sender, EventArgs e)
        {
            
            string pattern = @"[^0-9\-]"; 
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(pattern);

    
            string currentText = txtCustomerPhoneNumber.Text;

            string newText = regex.Replace(currentText, string.Empty);

            if (currentText != newText)
            {
                txtCustomerPhoneNumber.Text = newText;
                txtCustomerPhoneNumber.SelectionStart = newText.Length;

                MessageBox.Show("Please enter only numbers and dashes.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


       

        
        private void txtCustomerZip_TextChanged(object sender, EventArgs e)
        {
            string pattern = @"[^0-9]";
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(pattern);

            string currentText = txtCustomerZip.Text;

            string newText = regex.Replace(currentText, string.Empty);

            if (newText.Length > 32)
            {
                newText = newText.Substring(0, 32);
            }

            if (currentText != newText)
            {
                txtCustomerZip.Text = newText;
                txtCustomerZip.SelectionStart = newText.Length;

                MessageBox.Show("Please enter only digits, and ensure the number of digits does not exceed 32.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dataGridViewCustomerInfo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}