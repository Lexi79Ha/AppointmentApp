﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace C969_A_Harris
{
    public partial class AppointmentCalendarForm : Form
    {
        private readonly string connectionString = "Server=127.0.0.1;Database=client_schedule;Uid=sqlUser;Pwd=Passw0rd!;";
        private User loggedInUser;
        private SelectedAppointment selectedAppointment;
        private Appointment appointment;
        private readonly ReminderService reminderService;
        private readonly ReportService reportService;
        private readonly LoginHistoryService loginHistoryService;
        public List<Appointment> appointments;

        public AppointmentCalendarForm(User loggedInUser, Appointment appointment)
        {
            InitializeComponent();
            this.loggedInUser = loggedInUser;
            this.appointment = appointment;

            reminderService = new ReminderService(connectionString);
           
            loginHistoryService = new LoginHistoryService();

            ConfigureDataGridView();
            monthCalendar2.DateSelected += MonthCalendar2_DateSelected;
            LoadAllAppointments();

            OnUserLogin(loggedInUser);
            this.Load += AppointmentCalendarForm_Load;
        }

   
        private void button3_Click(object sender, EventArgs e)
        {
            
            var reportService = new ReportService();

          
            string appointmentTypesReportPath = @"Reports\AppointmentTypesByMonth.csv";
            string userSchedulesReportPath = @"Reports\UserSchedules.csv";
            string totalDurationReportPath = @"Reports\TotalAppointmentDurationPerUser.csv";

            string reportsDirectory = @"Reports";
            if (!Directory.Exists(reportsDirectory))
            {
                Directory.CreateDirectory(reportsDirectory);
            }

    
            reportService.WriteReportAppointmentTypesByMonthToFile(appointmentTypesReportPath);
            reportService.WriteReportUserSchedulesToFile(userSchedulesReportPath);
            reportService.WriteReportTotalAppointmentDurationToFile(totalDurationReportPath);

        
            MessageBox.Show("Reports generated successfully in the 'Reports' folder!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private async void OnUserLogin(User user)
        {
            try
            {
                await reminderService.CheckUpcomingAppointments(user, async alertMessage =>
                {
                    MessageBox.Show(alertMessage, "Upcoming Appointment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                });
            }
            catch (Exception ex)
            {
           
                MessageBox.Show($"An error occurred while checking upcoming appointments: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }





        private void ConfigureDataGridView()
        {
            dataGridView2.Columns.Clear();
            dataGridView2.Columns.Add("CustomerName", "Customer Name");
            dataGridView2.Columns.Add("Type", "Type");
            dataGridView2.Columns.Add("Description", "Description");
            dataGridView2.Columns.Add("Start", "Start");
            dataGridView2.Columns.Add("End", "End");
            
        }

        private void LoadAllAppointments()
        {
            List<Appointment> appointments = GetAllAppointments();

            dataGridView2.Rows.Clear();

            foreach (var appointment in appointments)
            {
                dataGridView2.Rows.Add(appointment.CustomerName, appointment.Type, appointment.Description, appointment.Start, appointment.End);
            }
        }

        private void LoadAppointmentsByDate(DateTime selectedDate)
        {
            List<Appointment> appointments = GetAppointmentsByDate(selectedDate);

            dataGridView2.Rows.Clear();

            foreach (var appointment in appointments)
            {
                dataGridView2.Rows.Add(appointment.CustomerName,appointment.Type, appointment.Description, appointment.Start, appointment.End);
            }
        }

        private List<Appointment> GetAllAppointments()
        {
            List<Appointment> appointments = new List<Appointment>();

            string query = @"
        SELECT a.type, a.description, a.start, a.end, c.customerName 
        FROM appointment a 
        JOIN customer c ON a.customerId = c.customerId";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlCommand command = new MySqlCommand(query, connection);

                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Appointment appointment = new Appointment
                    {
                        Type = reader["type"].ToString(),
                        Description = reader["description"].ToString(),
                        Start = Convert.ToDateTime(reader["start"]),
                        End = Convert.ToDateTime(reader["end"]),
                        CustomerName = reader["customerName"].ToString()
                    };
                    appointments.Add(appointment);
                }

                connection.Close();
            }

            return appointments;
        }

        private List<Appointment> GetAppointmentsByDate(DateTime date)
        {
            List<Appointment> appointments = new List<Appointment>();

            string query = @"
        SELECT a.type, a.description, a.start, a.end, c.customerName 
        FROM appointment a 
        JOIN customer c ON a.customerId = c.customerId 
        WHERE DATE(a.start) = @selectedDate";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@selectedDate", date.Date);

                MySqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Appointment appointment = new Appointment
                    {
                        Type = reader["type"].ToString(),
                        Description = reader["description"].ToString(),
                        Start = Convert.ToDateTime(reader["start"]),
                        End = Convert.ToDateTime(reader["end"]),
                        CustomerName = reader["customerName"].ToString()
                    };
                    appointments.Add(appointment);
                }

                connection.Close();
            }

            return appointments;
        }

        private void MonthCalendar2_DateSelected(object sender, DateRangeEventArgs e)
        {
            DateTime selectedDate = monthCalendar2.SelectionStart;
            LoadAppointmentsByDate(selectedDate); 
        }

        private void AddCustomer_Click(object sender, EventArgs e)
        {
            CustomerForm customerForm = new CustomerForm(loggedInUser);
            customerForm.Show();
        }

        private void ModifyCustomer_Click(object sender, EventArgs e)
        {
            CustomerForm customerForm = new CustomerForm(loggedInUser);
            customerForm.Show();
        }

        private void DeleteCustomer_Click(object sender, EventArgs e)
        {
            CustomerForm customerForm = new CustomerForm(loggedInUser);
            customerForm.Show();
        }

        private void AppointBook_Click(object sender, EventArgs e)
        {
            AddModifyAppointmentForm addModifyAppointmentForm = new AddModifyAppointmentForm(loggedInUser);
            addModifyAppointmentForm.Show();
        }

        private void Customerslabel_Click(object sender, EventArgs e)
        {

        }

        private void AppointmentCalendarForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            ModifyAppointmentForm modifyForm = new ModifyAppointmentForm(loggedInUser, selectedAppointment);
            modifyForm.Show();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddCustomer addcustomer = new AddCustomer(loggedInUser);
            addcustomer.Show();
        }

        
    }
}
