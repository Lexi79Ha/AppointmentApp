﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace C969_A_Harris
{
    public static class Configuration
    {
        public static string ConnectionString { get; } = "Server=127.0.0.1;Database=client_schedule;Uid=sqlUser;Pwd=Passw0rd!;";
    }
}
