﻿namespace C969_A_Harris
{
    partial class AddCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCustomerZip = new System.Windows.Forms.TextBox();
            this.txtCustomerCountry = new System.Windows.Forms.TextBox();
            this.txtCustomerCity = new System.Windows.Forms.TextBox();
            this.btnCustomerAdd = new System.Windows.Forms.Button();
            this.labelCustomerPhoneNumber = new System.Windows.Forms.Label();
            this.labelCustomerAddress = new System.Windows.Forms.Label();
            this.labelCustomerName = new System.Windows.Forms.Label();
            this.txtCustomerPhoneNumber = new System.Windows.Forms.TextBox();
            this.txtCustomerAddress = new System.Windows.Forms.TextBox();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(1192, 212);
            this.label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(513, 63);
            this.label4.TabIndex = 36;
            this.label4.Text = "Manage Customers";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label3.Location = new System.Drawing.Point(1116, 771);
            this.label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 38);
            this.label3.TabIndex = 35;
            this.label3.Text = "Country";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label2.Location = new System.Drawing.Point(1132, 679);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 38);
            this.label2.TabIndex = 34;
            this.label2.Text = "ZipCode";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label1.Location = new System.Drawing.Point(1196, 581);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 38);
            this.label1.TabIndex = 33;
            this.label1.Text = "City";
            // 
            // txtCustomerZip
            // 
            this.txtCustomerZip.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtCustomerZip.Location = new System.Drawing.Point(1288, 667);
            this.txtCustomerZip.Margin = new System.Windows.Forms.Padding(6);
            this.txtCustomerZip.Name = "txtCustomerZip";
            this.txtCustomerZip.Size = new System.Drawing.Size(454, 44);
            this.txtCustomerZip.TabIndex = 32;
            this.txtCustomerZip.TextChanged += new System.EventHandler(this.txtCustomerZip_TextChanged);
            // 
            // txtCustomerCountry
            // 
            this.txtCustomerCountry.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtCustomerCountry.Location = new System.Drawing.Point(1288, 760);
            this.txtCustomerCountry.Margin = new System.Windows.Forms.Padding(6);
            this.txtCustomerCountry.Name = "txtCustomerCountry";
            this.txtCustomerCountry.Size = new System.Drawing.Size(454, 44);
            this.txtCustomerCountry.TabIndex = 31;
            // 
            // txtCustomerCity
            // 
            this.txtCustomerCity.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtCustomerCity.Location = new System.Drawing.Point(1288, 569);
            this.txtCustomerCity.Margin = new System.Windows.Forms.Padding(6);
            this.txtCustomerCity.Name = "txtCustomerCity";
            this.txtCustomerCity.Size = new System.Drawing.Size(454, 44);
            this.txtCustomerCity.TabIndex = 30;
            // 
            // btnCustomerAdd
            // 
            this.btnCustomerAdd.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnCustomerAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.btnCustomerAdd.Location = new System.Drawing.Point(1307, 979);
            this.btnCustomerAdd.Margin = new System.Windows.Forms.Padding(6);
            this.btnCustomerAdd.Name = "btnCustomerAdd";
            this.btnCustomerAdd.Size = new System.Drawing.Size(330, 98);
            this.btnCustomerAdd.TabIndex = 27;
            this.btnCustomerAdd.Text = "Add Customer";
            this.btnCustomerAdd.UseVisualStyleBackColor = false;
            this.btnCustomerAdd.Click += new System.EventHandler(this.btnCustomerAdd_Click);
            // 
            // labelCustomerPhoneNumber
            // 
            this.labelCustomerPhoneNumber.AutoSize = true;
            this.labelCustomerPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.labelCustomerPhoneNumber.Location = new System.Drawing.Point(1010, 860);
            this.labelCustomerPhoneNumber.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelCustomerPhoneNumber.Name = "labelCustomerPhoneNumber";
            this.labelCustomerPhoneNumber.Size = new System.Drawing.Size(236, 38);
            this.labelCustomerPhoneNumber.TabIndex = 26;
            this.labelCustomerPhoneNumber.Text = "Phone Number";
            // 
            // labelCustomerAddress
            // 
            this.labelCustomerAddress.AutoSize = true;
            this.labelCustomerAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.labelCustomerAddress.Location = new System.Drawing.Point(1134, 496);
            this.labelCustomerAddress.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelCustomerAddress.Name = "labelCustomerAddress";
            this.labelCustomerAddress.Size = new System.Drawing.Size(138, 38);
            this.labelCustomerAddress.TabIndex = 25;
            this.labelCustomerAddress.Text = "Address";
            // 
            // labelCustomerName
            // 
            this.labelCustomerName.AutoSize = true;
            this.labelCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.labelCustomerName.Location = new System.Drawing.Point(1170, 417);
            this.labelCustomerName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.labelCustomerName.Name = "labelCustomerName";
            this.labelCustomerName.Size = new System.Drawing.Size(104, 38);
            this.labelCustomerName.TabIndex = 24;
            this.labelCustomerName.Text = "Name";
            // 
            // txtCustomerPhoneNumber
            // 
            this.txtCustomerPhoneNumber.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerPhoneNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtCustomerPhoneNumber.Location = new System.Drawing.Point(1288, 848);
            this.txtCustomerPhoneNumber.Margin = new System.Windows.Forms.Padding(6);
            this.txtCustomerPhoneNumber.Name = "txtCustomerPhoneNumber";
            this.txtCustomerPhoneNumber.Size = new System.Drawing.Size(454, 44);
            this.txtCustomerPhoneNumber.TabIndex = 22;
            this.txtCustomerPhoneNumber.TextChanged += new System.EventHandler(this.txtCustomerPhoneNumber_TextChanged);
            // 
            // txtCustomerAddress
            // 
            this.txtCustomerAddress.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtCustomerAddress.Location = new System.Drawing.Point(1288, 485);
            this.txtCustomerAddress.Margin = new System.Windows.Forms.Padding(6);
            this.txtCustomerAddress.Name = "txtCustomerAddress";
            this.txtCustomerAddress.Size = new System.Drawing.Size(454, 44);
            this.txtCustomerAddress.TabIndex = 21;
            this.txtCustomerAddress.TextChanged += new System.EventHandler(this.txtCustomerAddress_TextChanged);
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.txtCustomerName.Location = new System.Drawing.Point(1288, 406);
            this.txtCustomerName.Margin = new System.Windows.Forms.Padding(6);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(454, 44);
            this.txtCustomerName.TabIndex = 20;
            // 
            // AddCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(2978, 1615);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCustomerZip);
            this.Controls.Add(this.txtCustomerCountry);
            this.Controls.Add(this.txtCustomerCity);
            this.Controls.Add(this.btnCustomerAdd);
            this.Controls.Add(this.labelCustomerPhoneNumber);
            this.Controls.Add(this.labelCustomerAddress);
            this.Controls.Add(this.labelCustomerName);
            this.Controls.Add(this.txtCustomerPhoneNumber);
            this.Controls.Add(this.txtCustomerAddress);
            this.Controls.Add(this.txtCustomerName);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "AddCustomer";
            this.Text = "AddCustomer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCustomerZip;
        private System.Windows.Forms.TextBox txtCustomerCountry;
        private System.Windows.Forms.TextBox txtCustomerCity;
        private System.Windows.Forms.Button btnCustomerAdd;
        private System.Windows.Forms.Label labelCustomerPhoneNumber;
        private System.Windows.Forms.Label labelCustomerAddress;
        private System.Windows.Forms.Label labelCustomerName;
        private System.Windows.Forms.TextBox txtCustomerPhoneNumber;
        private System.Windows.Forms.TextBox txtCustomerAddress;
        private System.Windows.Forms.TextBox txtCustomerName;
    }
}