﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace C969_A_Harris
{
    public class ReportService
    {
        private string connectionString = "Server=127.0.0.1;Database=client_schedule;Uid=sqlUser;Pwd=Passw0rd!;";

        private MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }


        public void WriteReportAppointmentTypesByMonthToFile(string filePath)
        {
            var report = ReportAppointmentTypesByMonth();
            using (var writer = new StreamWriter(filePath))
            {
                writer.WriteLine("Month/Year,Type,Count");
                foreach (var entry in report)
                {
                    writer.WriteLine($"{entry.MonthYear},{entry.Type},{entry.Count}");
                }
            }
        }


        public void WriteReportUserSchedulesToFile(string filePath)
        {
            var report = ReportUserSchedules();
            using (var writer = new StreamWriter(filePath))
            {
                writer.WriteLine("UserId,Start,Type");
                foreach (var entry in report)
                {
                    int userId = entry.Key;
                    foreach (var appointment in entry.Value)
                    {
                        writer.WriteLine($"{userId},{appointment.Start},{appointment.Type}");
                    }
                }
            }
        }


        public void WriteReportTotalAppointmentDurationToFile(string filePath)
        {
            var report = ReportTotalAppointmentDurationPerUser();
            using (var writer = new StreamWriter(filePath))
            {
                writer.WriteLine("UserId,Total Duration (minutes)");
                foreach (var entry in report)
                {
                    writer.WriteLine($"{entry.UserId},{entry.TotalDuration}");
                }
            }
        }


        public List<(string MonthYear, string Type, int Count)> ReportAppointmentTypesByMonth()
        {
            var report = new List<(string MonthYear, string Type, int Count)>();
            using (var connection = GetConnection())
            {
                connection.Open();

                string query = @"
        SELECT 
            CONCAT(MONTH(Start), '/', YEAR(Start)) AS MonthYear,
            Type,
            COUNT(*) AS Count
        FROM appointment
        GROUP BY MonthYear, Type
        ORDER BY MonthYear, Type;";

                using (var command = new MySqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string monthYear = reader.GetString("MonthYear");
                            string type = reader.GetString("Type");
                            int count = reader.GetInt32("Count");

                            report.Add((monthYear, type, count));
                        }
                    }
                }
            }
            return report;
        }


        public Dictionary<int, List<(DateTime Start, DateTime End, string Type)>> ReportUserSchedules()
        {
            var userSchedules = new Dictionary<int, List<(DateTime Start, DateTime End, string Type)>>();
            using (var connection = GetConnection())
            {
                connection.Open();
                string query = @"
                SELECT UserId, Start, End, Type FROM appointment;";
                using (var command = new MySqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        var appointments = new List<(int UserId, DateTime Start,DateTime End, string Type)>();
                        while (reader.Read())
                        {
                            appointments.Add((reader.GetInt32("UserId"), reader.GetDateTime("Start"), reader.GetDateTime("End"), reader.GetString("Type")));
                        }
                        userSchedules = appointments.GroupBy(a => a.UserId)
                                                    .ToDictionary(g => g.Key, g => g.Select(a => (a.Start,a.End, a.Type)).ToList());
                    }
                }
            }
            return userSchedules;
        }

        public List<(int UserId, double TotalDuration)> ReportTotalAppointmentDurationPerUser()
        {
            var report = new List<(int UserId, double TotalDuration)>();
            using (var connection = GetConnection())
            {
                connection.Open();
                string query = @"
                SELECT UserId, Start, End FROM appointment;";
                using (var command = new MySqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        var appointments = new List<(int UserId, DateTime Start, DateTime End)>();
                        while (reader.Read())
                        {
                            appointments.Add((reader.GetInt32("UserId"), reader.GetDateTime("Start"), reader.GetDateTime("End")));
                        }
                        report = appointments.GroupBy(a => a.UserId)
                                             .Select(g => (g.Key, g.Sum(a => (a.End - a.Start).TotalMinutes)))
                                             .ToList();
                    }
                }
            }
            return report;
        }
    }
}