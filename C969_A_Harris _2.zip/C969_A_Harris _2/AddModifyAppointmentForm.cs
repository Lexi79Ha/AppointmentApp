﻿using MySql.Data.MySqlClient;
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;

namespace C969_A_Harris
{
    public partial class AddModifyAppointmentForm : Form
    {
        private BindingList<Customer> customerList = new BindingList<Customer>();
        private Customer selectedCustomer;
        private Database database;
        private readonly string connectionString = Configuration.ConnectionString;
        private User loggedInUser;
        

      
        public AddModifyAppointmentForm(User loggedInUser)
        {
            InitializeComponent();
            dataGridView1.CellClick += new DataGridViewCellEventHandler(dataGridViewCustomerInfo_CellClick);
            this.loggedInUser = loggedInUser;
            database = new Database(loggedInUser);
            InitializeDateTimePicker();
            SetupDataGridView();
            LoadCustomers();
            PopulateTimeSlots();
        
        }



        private void PopulateTimeSlots()
        {
            
            TimeSpan interval = TimeSpan.FromMinutes(15);
            TimeSpan startTime = new TimeSpan(9, 0, 0); 
            TimeSpan endTime = new TimeSpan(17, 0, 0); 

          
            comboBoxStartTime.Items.Clear();
            comboBoxEndTime.Items.Clear();

            for (TimeSpan time = startTime; time <= endTime; time += interval)
            {
                
                DateTime timeAsDateTime = DateTime.Today.Add(time);
                string timeString = timeAsDateTime.ToString("hh:mm tt");

                comboBoxStartTime.Items.Add(timeString);
                comboBoxEndTime.Items.Add(timeString);
            }

      
            if (comboBoxStartTime.Items.Count > 0)
                comboBoxStartTime.SelectedIndex = 0;
            if (comboBoxEndTime.Items.Count > 0)
                comboBoxEndTime.SelectedIndex = 0;
        }
        private void dateTimePickerDate_ValueChanged(object sender, EventArgs e)
        {
           
            PopulateTimeSlots();
        }

        private void comboBoxTimeSlots_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (comboBoxStartTime.SelectedItem != null)
            {
                string selectedTime = comboBoxStartTime.SelectedItem.ToString();
                DateTime selectedDate = dateTimePicker.Value.Date;
                DateTime startTime = DateTime.ParseExact(selectedTime, "hh:mm tt", null);

               
                DateTime appointmentStartTime = new DateTime(selectedDate.Year, selectedDate.Month, selectedDate.Day, startTime.Hour, startTime.Minute, 0);

              
                dateTimePicker.Value = appointmentStartTime.AddMinutes(15); 
            }
        }


        private void SetupDataGridView()
        {
           
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.MultiSelect = false;

      
            dataGridView1.Columns.Clear();

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "customerId",
                HeaderText = "Customer ID",

                DataPropertyName = "CustomerId",
                Visible = false
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Name",
                HeaderText = "Name",
                DataPropertyName = "Name"
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Address",
                HeaderText = "Address",
                DataPropertyName = "Address"
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "PhoneNumber",
                HeaderText = "Phone Number",
                DataPropertyName = "PhoneNumber"
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "City",
                HeaderText = "City",
                DataPropertyName = "City"
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Country",
                HeaderText = "Country",
                DataPropertyName = "Country"
            });

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "ZipCode",
                HeaderText = "Zip Code",
                DataPropertyName = "ZipCode"
            });
        }


        private void LoadCustomers()
        {
            var customers = database.GetAllCustomers();
            RefreshCustomerList();
            foreach (var customer in customers)
            {
                Console.WriteLine($"Customer ID: {customer.CustomerId}"); 
            }
            customerList = new BindingList<Customer>(customers);
            dataGridView1.DataSource = customerList;
        }

        private void RefreshCustomerList()
        {
            var customers = database.GetAllCustomers();
            customerList = new BindingList<Customer>(customers);
            dataGridView1.DataSource = customerList;
        }


        private void dataGridViewCustomerInfo_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedCustomer = (Customer)dataGridView1.Rows[e.RowIndex].DataBoundItem;

                textBox3.Text = selectedCustomer.Name;

            }
        }

        


       

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox3.Text))
            {
                MessageBox.Show("Please select a customer from the menu.", "No Customer Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Search_Click(object sender, EventArgs e)
        {

            string searchTerm = textBox2.Text.Trim().ToLower();

            if (string.IsNullOrEmpty(searchTerm))
            {
                MessageBox.Show("Please enter a search term.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool found = false; 

            dataGridView1.ClearSelection();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.IsNewRow) continue;

                string name = row.Cells["Name"].Value.ToString().ToLower();

                if (name.Contains(searchTerm))
                {
                    row.Selected = true;
                    found = true; 
                }
            }

            if (!found)
            {
                MessageBox.Show("No matching customers found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button2_Click(object sender, EventArgs e)
{
    if (selectedCustomer == null)
    {
        MessageBox.Show("Please select a customer before creating an appointment.", "No Customer Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return;
    }

    string customerName = textBox3.Text.Trim();
    string location = textBox1.Text.Trim();
    string appointmentDescription = descriptiontxt.Text.Trim();
    string appointmentType = titletxt.Text.Trim();
    string url = "not needed";
    string contact = "not needed";


    DateTime startTime = DateTime.ParseExact(comboBoxStartTime.SelectedItem.ToString(), "hh:mm tt", null);
    DateTime endTime = DateTime.ParseExact(comboBoxEndTime.SelectedItem.ToString(), "hh:mm tt", null);

    DateTime appointmentStartTime = dateTimePicker.Value.Date + startTime.TimeOfDay;
    DateTime appointmentEndTime = dateTimePicker.Value.Date + endTime.TimeOfDay;

    TimeZoneInfo estZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
    DateTime estStartTime = TimeZoneInfo.ConvertTime(appointmentStartTime, estZone);
    DateTime estEndTime = TimeZoneInfo.ConvertTime(appointmentEndTime, estZone);

    if (!IsWithinBusinessHours(estStartTime, estEndTime))
    {
        MessageBox.Show("Appointment must be scheduled between 9:00 AM and 5:00 PM, Monday–Friday.", "Invalid Time", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return;
    }

    if (estStartTime >= estEndTime)
    {
        MessageBox.Show("End time must be after the start time.", "Invalid Time", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return;
    }

    if (IsOverlapping(estStartTime, estEndTime))
    {
        MessageBox.Show("The selected time slot overlaps with an existing appointment.", "Time Overlap", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return;
    }

    try
    {
        string userName = "Test"; 

        using (MySqlConnection connection = new MySqlConnection(connectionString))
        {
            connection.Open();

          
            string fetchUserIdQuery = "SELECT userId FROM user WHERE userName = @userName";
            MySqlCommand fetchUserIdCmd = new MySqlCommand(fetchUserIdQuery, connection);
            fetchUserIdCmd.Parameters.AddWithValue("@userName", userName);

            object result = fetchUserIdCmd.ExecuteScalar();
            if (result == null)
            {
                MessageBox.Show("User not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int userId = Convert.ToInt32(result);

           
            string insertAppointmentQuery = @"
                INSERT INTO appointment 
                (customerId, userId, title, description, type, location, contact, url, start, end, createDate, createdBy, lastUpdate, lastUpdateBy) 
                VALUES 
                (@customerId, @userId, @title, @description, @type, @location, @contact, @url, @start, @end, @createDate, @createdBy, @lastUpdate, @lastUpdateBy)";

            MySqlCommand appointmentCmd = new MySqlCommand(insertAppointmentQuery, connection);
            appointmentCmd.Parameters.AddWithValue("@customerId", selectedCustomer.CustomerId);
            appointmentCmd.Parameters.AddWithValue("@userId", userId);
            appointmentCmd.Parameters.AddWithValue("@title", "not needed");
            appointmentCmd.Parameters.AddWithValue("@description", appointmentDescription);
            appointmentCmd.Parameters.AddWithValue("@type", appointmentType);
            appointmentCmd.Parameters.AddWithValue("@location", location);
            appointmentCmd.Parameters.AddWithValue("@contact", contact);
            appointmentCmd.Parameters.AddWithValue("@url", url);
            appointmentCmd.Parameters.AddWithValue("@start", estStartTime);
            appointmentCmd.Parameters.AddWithValue("@end", estEndTime);
            appointmentCmd.Parameters.AddWithValue("@createDate", DateTime.Now);
            appointmentCmd.Parameters.AddWithValue("@createdBy", userName);
            appointmentCmd.Parameters.AddWithValue("@lastUpdate", DateTime.Now);
            appointmentCmd.Parameters.AddWithValue("@lastUpdateBy", userName);

            appointmentCmd.ExecuteNonQuery();

            MessageBox.Show("Appointment created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    
                    
                    this.Close();
                   
                    AppointmentCalendarForm appointmentCalendarForm = new AppointmentCalendarForm(loggedInUser, null);
                    appointmentCalendarForm.Show();
                }
    }
    catch (MySqlException ex)
    {
        MessageBox.Show($"Database error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
    catch (Exception ex)
    {
        MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}

        
        private void comboBoxStartTime_SelectedIndexChanged(object sender, EventArgs e)
        {
            ValidateTimes();
        }

        private void comboBoxEndTime_SelectedIndexChanged(object sender, EventArgs e)
        {
            ValidateTimes();
        }

        private void ValidateTimes()
        {
            if (comboBoxStartTime.SelectedItem != null && comboBoxEndTime.SelectedItem != null)
            {
                DateTime startTime = DateTime.ParseExact(comboBoxStartTime.SelectedItem.ToString(), "hh:mm tt", null);
                DateTime endTime = DateTime.ParseExact(comboBoxEndTime.SelectedItem.ToString(), "hh:mm tt", null);

                if (endTime <= startTime)
                {
                    MessageBox.Show("End time must be after the start time.", "Invalid Time", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    comboBoxEndTime.SelectedIndex = comboBoxStartTime.SelectedIndex + 1; // Reset to next available time
                }
            }
        }

        private bool IsWithinBusinessHours(DateTime startTime, DateTime endTime)
        {
            TimeZoneInfo estZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
            DateTime businessStart = TimeZoneInfo.ConvertTime(DateTime.Today.AddHours(9), estZone);
            DateTime businessEnd = TimeZoneInfo.ConvertTime(DateTime.Today.AddHours(17), estZone);

            
            return (startTime.DayOfWeek >= DayOfWeek.Monday && startTime.DayOfWeek <= DayOfWeek.Friday &&
                    endTime.DayOfWeek >= DayOfWeek.Monday && endTime.DayOfWeek <= DayOfWeek.Friday &&
                    startTime.TimeOfDay >= businessStart.TimeOfDay && endTime.TimeOfDay <= businessEnd.TimeOfDay);
        }


        private bool IsOverlapping(DateTime startTime, DateTime endTime)
        {
            
            string selectAppointmentsQuery = @"
        SELECT COUNT(*) 
        FROM appointment
        WHERE (start < @end AND end > @start)";

            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                connection.Open();

                MySqlCommand checkOverlapCmd = new MySqlCommand(selectAppointmentsQuery, connection);
                checkOverlapCmd.Parameters.AddWithValue("@start", startTime);
                checkOverlapCmd.Parameters.AddWithValue("@end", endTime);

                int overlapCount = Convert.ToInt32(checkOverlapCmd.ExecuteScalar());
                return overlapCount > 0;
            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count - 1) // Check if the click is within valid row indices
            {
                selectedCustomer = (Customer)dataGridView1.Rows[e.RowIndex].DataBoundItem;

                
                textBox3.Text = selectedCustomer.Name;
            }
        }

        private void InitializeDateTimePicker()
        {
            
            dateTimePicker.MinDate = DateTime.Today;
            dateTimePicker.MaxDate = DateTime.Today.AddYears(10); 
            dateTimePicker.Value = DateTime.Today; 
        }

    }
}