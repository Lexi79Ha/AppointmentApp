﻿using System;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace C969_A_Harris
{
    public class ReminderService
    {
        private readonly string connectionString;

        public ReminderService(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public async Task CheckUpcomingAppointments(User user, Func<string, Task> alertCallback)
        {
            TimeZoneInfo userTimeZone = TimeZoneInfo.Local;
            TimeZoneInfo easternTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");

            try
            {
                DateTime userLocalTime = DateTime.Now;
                DateTime currentTimeInEastern = TimeZoneInfo.ConvertTime(userLocalTime, userTimeZone, easternTimeZone);

                DateTime futureTimeInEastern = currentTimeInEastern.AddMinutes(15);

                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    await connection.OpenAsync();
                    Console.WriteLine("Database connection opened.");

                    string query = @"
            SELECT appointmentId, start, type
            FROM appointment
            WHERE userId = @UserId AND start BETWEEN @CurrentTime AND @FutureTime;
            ";

                    using (MySqlCommand command = new MySqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@UserId", user.UserId);
                        command.Parameters.AddWithValue("@CurrentTime", currentTimeInEastern);
                        command.Parameters.AddWithValue("@FutureTime", futureTimeInEastern);

                        Console.WriteLine("Executing query...");

                        using (MySqlDataReader reader = (MySqlDataReader)await command.ExecuteReaderAsync())
                        {
                            bool appointmentsFound = false;

                            while (await reader.ReadAsync())
                            {
                                appointmentsFound = true;

                                int appointmentId = reader.GetInt32("appointmentId");
                                DateTime startET = reader.GetDateTime("start"); 
                                string type = reader.GetString("type");

                                Console.WriteLine($"Appointment found: ID = {appointmentId}, Type = {type}, Start (EST) = {startET}");

                                DateTime startUserTimeZone = TimeZoneInfo.ConvertTime(startET, easternTimeZone, userTimeZone);
                                DateTime currentTimeInUserZone = TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, userTimeZone);

                                Console.WriteLine($"Converted Start (User Time Zone): {startUserTimeZone}");
                                Console.WriteLine($"Current Time (User Time Zone): {currentTimeInUserZone}");

                                if (startUserTimeZone <= currentTimeInUserZone.AddMinutes(15) && startUserTimeZone > currentTimeInUserZone)
                                {
                                    Console.WriteLine($"Reminder: Appointment '{type}' at {startUserTimeZone} is in less than 15 minutes.");

                                    await Task.Delay(500);

                                    if (alertCallback != null)
                                    {
                                        await alertCallback($"Reminder: You have an appointment '{type}' in less than 15 minutes at {startUserTimeZone}.");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Alert callback is null.");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine($"No reminder needed for appointment '{type}' at {startUserTimeZone}.");
                                }
                            }

                            if (!appointmentsFound)
                            {
                                Console.WriteLine("No upcoming appointments found in the next 15 minutes.");
                            }
                        }
                    }
                }
            }
            catch (MySqlException sqlEx)
            {
                Console.WriteLine($"MySQL Error: {sqlEx.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception occurred: {ex.Message}");
            }
        }
    }
}