﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using Org.BouncyCastle.Pqc.Crypto.Lms;


namespace C969_A_Harris
{
    public partial class AddCustomer : Form
    {
       
        
        private BindingList<Customer> customerList = new BindingList<Customer>();
        private Customer selectedCustomer;
        private Database database;
        private readonly string connectionString = Configuration.ConnectionString;
        private User loggedInUser;
        
    
        public AddCustomer(User loggedInUser)
        {
            InitializeComponent();
            this.loggedInUser = loggedInUser;
            database = new Database(loggedInUser);
            

           
        }


        private void btnCustomerAdd_Click(object sender, EventArgs e)
        {
            string customerName = txtCustomerName.Text.Trim();
            string address = txtCustomerAddress.Text.Trim();
            string phoneNumber = txtCustomerPhoneNumber.Text.Trim();
            string city = txtCustomerCity.Text.Trim();
            string country = txtCustomerCountry.Text.Trim();
            string zipCode = txtCustomerZip.Text.Trim();

            if (string.IsNullOrEmpty(customerName) || string.IsNullOrEmpty(address) ||
                string.IsNullOrEmpty(phoneNumber) || string.IsNullOrEmpty(city) ||
                string.IsNullOrEmpty(country) || string.IsNullOrEmpty(zipCode))
            {
                MessageBox.Show("Please fill out all fields.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    
                    int countryId = GetOrCreateCountryId(connection, country);

                    
                    int cityId = GetOrCreateCityId(connection, city, countryId);

                   
                    int addressId = GetOrCreateAddressId(connection, address, cityId, zipCode, phoneNumber);

                
                    string insertCustomerQuery = @"
                INSERT INTO customer (customerName, addressId, active, createDate, createdBy, lastUpdateBy) 
                VALUES (@customerName, @addressId, 1, NOW(), @createdBy, @lastUpdateBy)";

                    MySqlCommand customerCmd = new MySqlCommand(insertCustomerQuery, connection);
                    customerCmd.Parameters.AddWithValue("@customerName", customerName);
                    customerCmd.Parameters.AddWithValue("@addressId", addressId);

                    customerCmd.Parameters.AddWithValue("@createdBy", loggedInUser.UserName);
                    customerCmd.Parameters.AddWithValue("@lastUpdateBy", loggedInUser.UserName);
                    customerCmd.ExecuteNonQuery();

                    MessageBox.Show("Customer added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    RefreshCustomerList();
                    this.Close();
                  
                }
            }
           
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
       private void RefreshCustomerList()
        {
            try
            {
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();

                    // Query to get all required columns for the Customer constructor
                    string query = @"
                SELECT 
                    c.customerId, 
                    c.customerName, 
                    a.address, 
                    a.phone, 
                    ci.city, 
                    co.country, 
                    a.postalCode AS zipCode, 
                    a.addressId, 
                    ci.cityId, 
                    co.countryId
                FROM customer c
                JOIN address a ON c.addressId = a.addressId
                JOIN city ci ON a.cityId = ci.cityId
                JOIN country co ON ci.countryId = co.countryId";

                    MySqlCommand cmd = new MySqlCommand(query, connection);

                    // Execute the query and populate the customerList
                    MySqlDataReader reader = cmd.ExecuteReader();
                    var customers = new List<Customer>();

                    while (reader.Read())
                    {
                        var customer = new Customer(
                            reader.GetInt32("customerId"),
                            reader.GetString("customerName"),
                            reader.GetString("address"),
                            reader.GetString("phone"),
                            reader.GetString("city"),
                            reader.GetString("country"),
                            reader.GetString("zipCode"),
                            reader.GetInt32("addressId"),
                            reader.GetInt32("cityId"),
                            reader.GetInt32("countryId")
                        );
                        customers.Add(customer);
                    }

                   
                    customerList = new BindingList<Customer>(customers);

                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while refreshing the customer list: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private int GetOrCreateAddressId(MySqlConnection connection, string address, int cityId, string postalCode, string phone)
        {
         
            string selectAddressQuery = "SELECT addressId FROM address WHERE address = @address AND cityId = @cityId AND postalCode = @postalCode";
            MySqlCommand selectAddressCmd = new MySqlCommand(selectAddressQuery, connection);
            selectAddressCmd.Parameters.AddWithValue("@address", address);
            selectAddressCmd.Parameters.AddWithValue("@cityId", cityId);
            selectAddressCmd.Parameters.AddWithValue("@postalCode", postalCode);

            object result = selectAddressCmd.ExecuteScalar();
            if (result != null)
            {
                return Convert.ToInt32(result);
            }

            
            string insertAddressQuery = @"
        INSERT INTO address (address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdateBy) 
        VALUES (@address, @address2, @cityId, @postalCode, @phone, NOW(), @createdBy, @lastUpdateBy)";
            MySqlCommand insertAddressCmd = new MySqlCommand(insertAddressQuery, connection);
            insertAddressCmd.Parameters.AddWithValue("@address", address);
            insertAddressCmd.Parameters.AddWithValue("@address2", "");  
            insertAddressCmd.Parameters.AddWithValue("@cityId", cityId);
            insertAddressCmd.Parameters.AddWithValue("@postalCode", postalCode);
            insertAddressCmd.Parameters.AddWithValue("@phone", phone);
            insertAddressCmd.Parameters.AddWithValue("@createdBy", loggedInUser.UserName);
            insertAddressCmd.Parameters.AddWithValue("@lastUpdateBy", loggedInUser.UserName);
            insertAddressCmd.ExecuteNonQuery();

            
            return (int)insertAddressCmd.LastInsertedId;
        }
        private int GetOrCreateCityId(MySqlConnection connection, string cityName, int countryId)
        {
            int cityId = 0;
            bool cityExists = false;

            try
            {
                
                string selectCityQuery = "SELECT cityId FROM city WHERE city = @city AND countryId = @countryId";
                MySqlCommand selectCityCmd = new MySqlCommand(selectCityQuery, connection);
                selectCityCmd.Parameters.AddWithValue("@city", cityName);
                selectCityCmd.Parameters.AddWithValue("@countryId", countryId);

                object result = selectCityCmd.ExecuteScalar();
                if (result != null)
                {
                    cityId = Convert.ToInt32(result);
                    cityExists = true;
                }
            }
            catch (MySqlException ex) when (ex.Number == 1062) 
            {
                

            }

            if (!cityExists)
            {
                
                try
                {
                    string insertCityQuery = "INSERT INTO city (city, countryId, createDate, createdBy, lastUpdateBy) VALUES (@city, @countryId, NOW(), @createdBy, @lastUpdateBy)";
                    MySqlCommand insertCityCmd = new MySqlCommand(insertCityQuery, connection);
                    insertCityCmd.Parameters.AddWithValue("@city", cityName);
                    insertCityCmd.Parameters.AddWithValue("@countryId", countryId);
                    insertCityCmd.Parameters.AddWithValue("@createdBy", loggedInUser.UserName);
                    insertCityCmd.Parameters.AddWithValue("@lastUpdateBy", loggedInUser.UserName);
                    insertCityCmd.ExecuteNonQuery();

                   
                    cityId = (int)insertCityCmd.LastInsertedId;
                }
                catch (MySqlException ex) when (ex.Number == 1062) 
                {
                    


                    
                    cityId = GetNextAvailableCityId(connection, cityName, countryId);
                }
            }

            return cityId;
        }

        private int GetNextAvailableCityId(MySqlConnection connection, string cityName, int countryId)
        {
            int newCityId = 0;
            bool idFound = false;

            while (!idFound)
            {
                try
                {
                  
                    newCityId = GenerateNewCityId();

              
                    string checkCityIdQuery = "SELECT COUNT(*) FROM city WHERE cityId = @cityId";
                    MySqlCommand checkCityIdCmd = new MySqlCommand(checkCityIdQuery, connection);
                    checkCityIdCmd.Parameters.AddWithValue("@cityId", newCityId);

                    int count = Convert.ToInt32(checkCityIdCmd.ExecuteScalar());
                    if (count == 0)
                    {
                        idFound = true;
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Error checking cityId availability. Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

          
            try
            {
                string insertCityQuery = "INSERT INTO city (cityId, city, countryId, createDate, createdBy, lastUpdateBy) VALUES (@cityId, @city, @countryId, NOW(), @createdBy, @lastUpdateBy)";
                MySqlCommand insertCityCmd = new MySqlCommand(insertCityQuery, connection);
                insertCityCmd.Parameters.AddWithValue("@cityId", newCityId);
                insertCityCmd.Parameters.AddWithValue("@city", cityName);
                insertCityCmd.Parameters.AddWithValue("@countryId", countryId);
                insertCityCmd.Parameters.AddWithValue("@createdBy", loggedInUser.UserName);
                insertCityCmd.Parameters.AddWithValue("@lastUpdateBy", loggedInUser.UserName);
                insertCityCmd.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error inserting new city. Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return newCityId;
        }

        private int GetOrCreateCountryId(MySqlConnection connection, string countryName)
        {
            
            string selectCountryQuery = "SELECT countryId FROM country WHERE country = @country";
            MySqlCommand selectCountryCmd = new MySqlCommand(selectCountryQuery, connection);
            selectCountryCmd.Parameters.AddWithValue("@country", countryName);

            object result = selectCountryCmd.ExecuteScalar();
            if (result != null)
            {
                return Convert.ToInt32(result);
            }

            
            string insertCountryQuery = "INSERT INTO country (country, createDate, createdBy, lastUpdateBy) VALUES (@country, NOW(), @createdBy, @lastUpdateBy)";
            MySqlCommand insertCountryCmd = new MySqlCommand(insertCountryQuery, connection);
            insertCountryCmd.Parameters.AddWithValue("@country", countryName);
            insertCountryCmd.Parameters.AddWithValue("@createdBy", loggedInUser.UserName);
            insertCountryCmd.Parameters.AddWithValue("@lastUpdateBy", loggedInUser.UserName);
            insertCountryCmd.ExecuteNonQuery();

            return (int)insertCountryCmd.LastInsertedId;
        }

        private int GenerateNewCityId()
        {
            
            return new Random().Next(1, 10000); 
        }

        private void txtCustomerAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCustomerPhoneNumber_TextChanged(object sender, EventArgs e)
        
        {
           
            string pattern = @"[^0-9\-]"; 
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(pattern);

            
            string currentText = txtCustomerPhoneNumber.Text;

            
            string newText = regex.Replace(currentText, string.Empty);

           
            if (currentText != newText)
            {
                txtCustomerPhoneNumber.Text = newText;
                
                txtCustomerPhoneNumber.SelectionStart = newText.Length;

                
                MessageBox.Show("Please enter only numbers and dashes.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void txtCustomerZip_TextChanged(object sender, EventArgs e)
        {
           
            string pattern = @"[^0-9]"; 
            System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex(pattern);

            string currentText = txtCustomerZip.Text;

       
            string newText = regex.Replace(currentText, string.Empty);

            if (newText.Length > 32)
            {
                newText = newText.Substring(0, 32); 
            }

            
            if (currentText != newText)
            {
                txtCustomerZip.Text = newText;
             
                txtCustomerZip.SelectionStart = newText.Length;

                // Show an error message
                MessageBox.Show("Please enter only digits, and ensure the number of digits does not exceed 32.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
