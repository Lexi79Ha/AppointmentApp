﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using C969_A_Harris;
using System.Windows.Forms;




namespace C969_A_Harris
{
    public class LoginHistoryService
    {
        private readonly string filePath;

        public LoginHistoryService()
        {
            // File will be found C969_A_Harris/Bin/Debug/Login_History.txt
            filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Login_History.txt");
        }

        public void RecordLoginHistory(User user)
        {
            try
            {
                string directory = Path.GetDirectoryName(filePath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                
                string logEntry = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - User {user.UserName} logged in.";

                
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine(logEntry);
                    writer.Flush(); 
                }

             
            }
            catch (Exception ex)
            {
                
                string errorLogPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Error_Log.txt");
                File.WriteAllText(errorLogPath, ex.ToString());
                MessageBox.Show($"An error occurred while recording login history: {ex.Message}");
            }
        }
    }
}
